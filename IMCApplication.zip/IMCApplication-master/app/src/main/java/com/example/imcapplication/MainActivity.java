package com.example.imcapplication;

import static com.example.imcapplication.R.id.buttonCalcular;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText nome, altura, peso;
    Button botaoCalcular, botaoLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = findViewById(R.id.editTextNome);
        altura = findViewById(R.id.editTextAltura);
        peso = findViewById(R.id.editTextPeso);
        botaoCalcular = findViewById(buttonCalcular);
        botaoLimpar = findViewById(R.id.buttonLimpar);

        // Ação do botão "Calcular IMC"
        botaoCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIMC();
            }
        });

        // Ação do botão "Limpar"
        botaoLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nome.setText(""); // Limpa o campo Nome
                altura.setText(""); // Limpa o campo Altura
                peso.setText(""); // Limpa o campo Peso
                nome.requestFocus(); // Coloca o cursor no primeiro campo
            }
        });
    }
    // Ação do botão "calcularIMC"
    public void calcularIMC() {
        if (TextUtils.isEmpty(nome.getText().toString())) {
            nome.setError("Campo obrigatório!");
            return;
        }
        if (TextUtils.isEmpty(altura.getText().toString())) {
            altura.setError("Campo obrigatório!");
            return;
        }
        if (TextUtils.isEmpty(peso.getText().toString())) {
            peso.setError("Campo obrigatório!");
            return;
        }

        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("nome", nome.getText().toString());
        intent.putExtra("altura", altura.getText().toString());
        intent.putExtra("peso", peso.getText().toString());
        startActivity(intent);
    }
}