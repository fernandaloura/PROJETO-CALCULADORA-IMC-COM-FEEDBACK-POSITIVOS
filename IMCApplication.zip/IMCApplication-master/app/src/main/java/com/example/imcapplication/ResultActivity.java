package com.example.imcapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    TextView resultado;
    ImageView imageViewResult;
    String strNome;
    Float fltAltura, fltPeso, fltResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Conectar os elementos do layout
        resultado = findViewById(R.id.textViewResult);
        imageViewResult = findViewById(R.id.imageViewResult);

        // Receber os valores da outra Activity
        Intent intent = getIntent();
        strNome = intent.getStringExtra("nome");
        fltAltura = Float.parseFloat(intent.getStringExtra("altura"));
        fltPeso = Float.parseFloat(intent.getStringExtra("peso"));
        fltResult = fltPeso / (fltAltura * fltAltura);

        // Criar a string do resultado
        String strResult = "Olá " + strNome + "!";
        strResult += "\nIMC = " + String.format("%.2f", fltResult); // Formatar para 2 casas decimais

        // Definir texto, imagem e feedback de acordo com o IMC
        if (fltResult < 18.5) {
            strResult += "\nAbaixo do peso";
            imageViewResult.setImageResource(R.drawable.abaixo_peso);
            strResult += "\n⚠️ Você está abaixo do peso ideal. Tente manter uma alimentação equilibrada e consulte um profissional de saúde para orientações. Você pode alcançar um equilíbrio saudável! 💪😊";
        } else if (fltResult < 25) {
            strResult += "\nPeso normal";
            imageViewResult.setImageResource(R.drawable.peso_normal);
            strResult += "\n🎉 Parabéns! Seu peso está dentro da faixa considerada saudável. Continue mantendo um estilo de vida equilibrado com boa alimentação e atividades físicas. 🏃‍♂️🥗";
        } else if (fltResult < 30) {
            strResult += "\nSobrepeso";
            imageViewResult.setImageResource(R.drawable.sobrepeso);
            strResult += "\n⚠️ Atenção! Você está um pouco acima do peso ideal. Pequenos ajustes na rotina, como alimentação saudável e exercícios, podem fazer a diferença. Você consegue! 💪😊";
        } else if (fltResult < 35) {
            strResult += "\nObesidade Grau 1";
            imageViewResult.setImageResource(R.drawable.obesidade1);
            strResult += "\n🔍 Seu IMC indica obesidade grau 1. Cuidar da alimentação e adotar um estilo de vida mais ativo pode ajudar a melhorar sua saúde. Procure um especialista para um acompanhamento adequado. Você pode melhorar sua qualidade de vida! 🌟💚";
        } else if (fltResult < 40) {
            strResult += "\nObesidade Grau 2";
            imageViewResult.setImageResource(R.drawable.obesidade2);
            strResult += "\n🚨 Seu IMC indica obesidade grau 2. É importante buscar apoio médico e fazer mudanças no estilo de vida para melhorar sua saúde. Pequenos passos fazem uma grande diferença! 💙💪";
        } else {
            strResult += "\nObesidade Grau 3";
            imageViewResult.setImageResource(R.drawable.obesidade3);
            strResult += "\n⚠️ Seu IMC indica obesidade grau 3. Recomendamos buscar orientação médica para um acompanhamento adequado. Sua saúde é valiosa, e cada passo conta para uma vida mais saudável e feliz! 💙😊";
        }

        // Exibir o resultado
        resultado.setText(strResult);

        // Conectar o botão
        Button buttonFechar = findViewById(R.id.buttonFechar);

// Definir ação de clique para retornar à tela principal
        buttonFechar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Limpa a pilha de atividades
                startActivity(intent);
                finish(); // Fecha a tela atual
            }

        });
    }
}