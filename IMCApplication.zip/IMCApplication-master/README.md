# IMCApplication


Aplicativo em Android Studio que aborda os seguintes conceitos:
 * Trocar Icone do App (ImageAsset)
 * Mudar o layout do teclado em EditText
 * Verificar Campos Vazios (TextUtils, setError)
 * Chamar nova tela e enviar valores (Intent, putExtra)
 * Converter Float/String (parse)
 * Concatenar String (+)
 * Botão Voltar no arquivo Manifest
